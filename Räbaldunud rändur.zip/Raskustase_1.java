public class Raskustase_1 extends Maatriks {
    private Sundmused sundmused = new Sundmused();

    public Raskustase_1() {
        super(5, 50);
    }

    public void executeEvent(int eventNum) throws InterruptedException {
        switch (eventNum) {
            case 1:
                sundmused.sundmus_1(1);
                break;
            case 2:
                sundmused.sundmus_2(1);
                break;
            case 3:
                sundmused.sundmus_3(1);
                break;
            case 4:
                sundmused.sundmus_4(1);
                break;
            case 5:
                sundmused.sundmus_5(1);
                break;
            case 6:
                sundmused.sundmus_6(1);
                break;
            case 7:
                sundmused.sundmus_7(1);
                break;
            case 8:
                sundmused.sundmus_8(1);
                break;
            case 9:
                sundmused.sundmus_9(1);
                break;
            case 10:
                sundmused.sundmus_10(1);
                break;
            case 11:
                sundmused.sundmus_11(1);
                break;
            case 12:
                sundmused.sundmus_12(1);
                break;
            case 13:
                sundmused.sundmus_13(1);
                break;
            case 14:
                sundmused.sundmus_14(1);
                break;
            case 15:
                sundmused.sundmus_15(1);
                break;
            case 16:
                sundmused.sundmus_16(1);
                break;
            case 17:
                sundmused.sundmus_17(1);
                break;
            case 18:
                sundmused.sundmus_18(1);
                break;
            case 19:
                sundmused.sundmus_19(1);
                break;
            case 20:
                sundmused.sundmus_20(1);
                break;
        }
    }
}